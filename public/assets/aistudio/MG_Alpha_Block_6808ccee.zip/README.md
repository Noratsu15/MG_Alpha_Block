# 🎓 EduStream - Plataforma de Videos Educativos

Sistema completo de aprendizaje en línea con autenticación JWT, gestión de videos, seguimiento de progreso y modo oscuro.

---

## 📁 Estructura del Proyecto

```
edustream/
├── database_schema.sql      # Esquema PostgreSQL + datos iniciales
├── server.js                # Backend API (Node.js + Express)
├── package.json             # Dependencias
├── .env.example             # Variables de entorno de ejemplo
├── index.html               # Frontend completo (SPA)
└── README.md               # Este archivo
```

---

## 🚀 Instalación Rápida

### 1. Requisitos
- **Node.js** 18+
- **PostgreSQL** 14+
- **npm** o **yarn**

### 2. Base de Datos

```bash
# Crear base de datos
psql -U postgres -c "CREATE DATABASE edustream;"

# Ejecutar esquema
psql -U postgres -d edustream -f database_schema.sql
```

### 3. Backend

```bash
# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Edita .env con tus credenciales de PostgreSQL

# Iniciar servidor
npm start
# o para desarrollo:
npm run dev
```

El servidor correrá en `http://localhost:3000`

### 4. Frontend

Abre `index.html` directamente en tu navegador o usa Live Server:

```bash
# Con Live Server (VS Code extension)
# Click derecho en index.html → "Open with Live Server"
# O usa npx serve:
npx serve .
```

---

## 🔐 Usuarios de Prueba

| Email | Contraseña | Rol |
|-------|-----------|-----|
| `admin@edustream.com` | `admin123` | Administrador |
| `estudiante@edustream.com` | `estudiante123` | Estudiante |

---

## 📡 API Endpoints

### Autenticación
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| POST | `/api/auth/register` | Registro de usuario |
| POST | `/api/auth/login` | Inicio de sesión |
| GET | `/api/auth/me` | Perfil del usuario |

### Videos
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/videos` | Listar videos (con filtros) |
| GET | `/api/videos/:id` | Detalle de video |
| POST | `/api/videos` | Crear video (profesor/admin) |

### Progreso
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/progress` | Progreso del usuario |
| POST | `/api/progress` | Actualizar progreso |

### Guardados
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/saved` | Videos guardados |
| POST | `/api/saved` | Guardar video |
| DELETE | `/api/saved/:videoId` | Eliminar de guardados |

### Dashboard
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/stats` | Estadísticas del estudiante |
| GET | `/api/categories` | Categorías disponibles |

### Admin
| Método | Endpoint | Descripción |
|--------|----------|-------------|
| GET | `/api/admin/users` | Listar usuarios |
| PATCH | `/api/admin/users/:id` | Actualizar usuario |

---

## 🎨 Características del Frontend

- ✅ **Modo Oscuro/Claro** - Persistente en localStorage
- ✅ **SPA (Single Page Application)** - Navegación sin recarga
- ✅ **Autenticación JWT** - Login/Register conectados al backend
- ✅ **Dashboard interactivo** - Estadísticas en tiempo real
- ✅ **Reproductor de video** - Con seguimiento de progreso automático
- ✅ **Videos guardados** - Bookmark con persistencia en BD
- ✅ **Búsqueda en tiempo real** - Filtrado de videos
- ✅ **Filtros por categoría** - Sidebar y pills interactivos
- ✅ **Diseño responsive** - Móvil, tablet y desktop
- ✅ **Animaciones suaves** - Transiciones y micro-interacciones

---

## 🛡️ Seguridad

- **Helmet** - Headers de seguridad HTTP
- **Rate Limiting** - Protección contra brute force
- **bcryptjs** - Hash de contraseñas con salt de 12 rounds
- **JWT** - Tokens firmados con expiración configurable
- **CORS** - Configuración de orígenes permitidos
- **Validación** - Express Validator en todos los inputs

---

## 🗄️ Esquema de Base de Datos

```
users              - Usuarios (estudiante, profesor, admin)
categories         - Materias/categorías de videos
videos             - Contenido de video
video_progress     - Progreso de visualización por usuario
saved_videos       - Videos guardados/favoritos
sessions           - Sesiones activas (logout multi-dispositivo)
```

---

## 🔧 Variables de Entorno (.env)

```env
PORT=3000
NODE_ENV=development

DB_HOST=localhost
DB_PORT=5432
DB_NAME=edustream
DB_USER=postgres
DB_PASSWORD=tu_password

JWT_SECRET=tu_clave_secreta_muy_larga
JWT_EXPIRES_IN=7d

CORS_ORIGIN=http://localhost:5500
```

---

## 📝 Próximos Pasos / Roadmap

- [ ] Subida de videos (multer / AWS S3)
- [ ] Comentarios y valoraciones en videos
- [ ] Notificaciones push
- [ ] Panel de administración completo
- [ ] Tests unitarios y de integración
- [ ] Dockerización
- [ ] CI/CD con GitHub Actions

---

## 📄 Licencia

MIT License - Libre para uso personal y comercial.

---

**Desarrollado con ❤️ para la educación.**
