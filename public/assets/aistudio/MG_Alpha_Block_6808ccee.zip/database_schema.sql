-- ============================================
-- EduStream - Esquema de Base de Datos
-- PostgreSQL 15+
-- ============================================

-- Extensiones
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- TABLAS
-- ============================================

-- Roles de usuario
CREATE TYPE user_role AS ENUM ('estudiante', 'profesor', 'administrador');

-- Usuarios
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL DEFAULT 'estudiante',
    avatar_url VARCHAR(500),
    is_active BOOLEAN DEFAULT true,
    email_verified BOOLEAN DEFAULT false,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Categorías / Materias
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    color VARCHAR(7) DEFAULT '#6366f1',
    icon VARCHAR(50),
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Videos
CREATE TABLE videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    video_url VARCHAR(500) NOT NULL,
    thumbnail_url VARCHAR(500),
    duration INTEGER NOT NULL, -- en segundos
    category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
    uploaded_by UUID REFERENCES users(id) ON DELETE SET NULL,
    tags TEXT[],
    is_published BOOLEAN DEFAULT false,
    published_at TIMESTAMP WITH TIME ZONE,
    view_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Progreso de visualización (estudiante - video)
CREATE TABLE video_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    progress_seconds INTEGER DEFAULT 0,
    progress_percent INTEGER DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),
    is_completed BOOLEAN DEFAULT false,
    completed_at TIMESTAMP WITH TIME ZONE,
    last_watched_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, video_id)
);

-- Videos guardados / favoritos
CREATE TABLE saved_videos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, video_id)
);

-- Sesiones (para logout en múltiples dispositivos)
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash VARCHAR(255) NOT NULL,
    ip_address INET,
    user_agent TEXT,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- ÍNDICES
-- ============================================
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_videos_category ON videos(category_id);
CREATE INDEX idx_videos_published ON videos(is_published, published_at);
CREATE INDEX idx_progress_user ON video_progress(user_id);
CREATE INDEX idx_progress_video ON video_progress(video_id);
CREATE INDEX idx_saved_user ON saved_videos(user_id);
CREATE INDEX idx_sessions_token ON sessions(token_hash);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- ============================================
-- FUNCIONES Y TRIGGERS
-- ============================================

-- Actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_videos_updated_at BEFORE UPDATE ON videos
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- DATOS INICIALES
-- ============================================

INSERT INTO categories (name, slug, description, color, icon, sort_order) VALUES
('Matemáticas', 'matematicas', 'Álgebra, cálculo, geometría y más', '#6366f1', 'bar-chart', 1),
('Ciencias', 'ciencias', 'Física, química y biología', '#10b981', 'flask', 2),
('Programación', 'programacion', 'Desarrollo de software y tecnología', '#f59e0b', 'code', 3),
('Idiomas', 'idiomas', 'Inglés, francés y otros idiomas', '#ec4899', 'globe', 4),
('Historia', 'historia', 'Historia universal y contemporánea', '#fbbf24', 'book', 5);

-- Usuario admin de prueba (password: admin123)
INSERT INTO users (full_name, email, password_hash, role, is_active, email_verified) VALUES
('Administrador', 'admin@edustream.com', crypt('admin123', gen_salt('bf')), 'administrador', true, true);

-- Usuario estudiante de prueba (password: estudiante123)
INSERT INTO users (full_name, email, password_hash, role, is_active, email_verified) VALUES
('Estudiante Demo', 'estudiante@edustream.com', crypt('estudiante123', gen_salt('bf')), 'estudiante', true, true);

-- Videos de ejemplo
INSERT INTO videos (title, description, video_url, thumbnail_url, duration, category_id, uploaded_by, tags, is_published, published_at, view_count) VALUES
('Introducción al Álgebra Lineal', 'Conceptos fundamentales de vectores y matrices', 'https://cdn.edustream.com/videos/algebra-lineal-intro.mp4', 'https://cdn.edustream.com/thumbs/algebra.jpg', 2720, (SELECT id FROM categories WHERE slug='matematicas'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['álgebra', 'matrices', 'vectores'], true, NOW(), 1200),
('Física Cuántica: Principios Básicos', 'Introducción a la mecánica cuántica', 'https://cdn.edustream.com/videos/fisica-cuantica.mp4', 'https://cdn.edustream.com/thumbs/fisica.jpg', 2325, (SELECT id FROM categories WHERE slug='ciencias'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['física', 'cuántica', 'átomos'], true, NOW(), 2100),
('JavaScript Moderno: ES6+', 'Nuevas características de JavaScript', 'https://cdn.edustream.com/videos/js-es6.mp4', 'https://cdn.edustream.com/thumbs/js.jpg', 3300, (SELECT id FROM categories WHERE slug='programacion'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['javascript', 'es6', 'frontend'], true, NOW(), 3400),
('Inglés Avanzado: Conversación', 'Práctica de conversación en inglés avanzado', 'https://cdn.edustream.com/videos/ingles-avanzado.mp4', 'https://cdn.edustream.com/thumbs/ingles.jpg', 2000, (SELECT id FROM categories WHERE slug='idiomas'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['inglés', 'conversación', 'avanzado'], true, NOW(), 920),
('Historia Universal: Revolución Francesa', 'Causas y consecuencias de la revolución', 'https://cdn.edustream.com/videos/revolucion-francesa.mp4', 'https://cdn.edustream.com/thumbs/historia.jpg', 2640, (SELECT id FROM categories WHERE slug='historia'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['historia', 'francia', 'revolución'], true, NOW(), 1500),
('React Hooks en Profundidad', 'useState, useEffect y hooks personalizados', 'https://cdn.edustream.com/videos/react-hooks.mp4', 'https://cdn.edustream.com/thumbs/react.jpg', 2895, (SELECT id FROM categories WHERE slug='programacion'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['react', 'hooks', 'frontend'], true, NOW(), 1800),
('Química Orgánica: Enlaces Carbono', 'Estructura y propiedades de los enlaces de carbono', 'https://cdn.edustream.com/videos/quimica-organica.mp4', 'https://cdn.edustream.com/thumbs/quimica.jpg', 2490, (SELECT id FROM categories WHERE slug='ciencias'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['química', 'orgánica', 'carbono'], true, NOW(), 750),
('Python para Ciencia de Datos', 'Pandas, NumPy y visualización de datos', 'https://cdn.edustream.com/videos/python-datascience.mp4', 'https://cdn.edustream.com/thumbs/python.jpg', 3720, (SELECT id FROM categories WHERE slug='programacion'), (SELECT id FROM users WHERE email='admin@edustream.com'), ARRAY['python', 'data science', 'pandas'], true, NOW(), 4200);