// ============================================
// EduStream - Backend API
// Node.js + Express + PostgreSQL + JWT
// ============================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// CONFIGURACIÓN DE BASE DE DATOS
// ============================================
const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'edustream',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '',
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

// Test de conexión
pool.connect((err, client, release) => {
    if (err) {
        console.error('❌ Error conectando a PostgreSQL:', err.message);
    } else {
        console.log('✅ Conectado a PostgreSQL');
        release();
    }
});

// ============================================
// MIDDLEWARES DE SEGURIDAD
// ============================================
app.use(helmet({
    crossOriginResourcePolicy: { policy: "cross-origin" }
}));

app.use(cors({
    origin: process.env.CORS_ORIGIN || '*',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: 100, // 100 requests por IP
    message: { error: 'Demasiadas solicitudes. Intenta más tarde.' }
});
app.use('/api/', limiter);

// Rate limiting específico para auth
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 10,
    message: { error: 'Demasiados intentos de autenticación. Intenta más tarde.' }
});

app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());

// ============================================
// UTILIDADES
// ============================================

const generateToken = (payload) => {
    return jwt.sign(payload, process.env.JWT_SECRET || 'fallback_secret', {
        expiresIn: process.env.JWT_EXPIRES_IN || '7d'
    });
};

const verifyToken = (token) => {
    return jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
};

// ============================================
// MIDDLEWARE DE AUTENTICACIÓN
// ============================================

const authenticate = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ error: 'Token no proporcionado' });
        }

        const token = authHeader.split(' ')[1];
        const decoded = verifyToken(token);

        // Verificar que el usuario sigue activo
        const userResult = await pool.query(
            'SELECT id, full_name, email, role, is_active FROM users WHERE id = $1',
            [decoded.userId]
        );

        if (userResult.rows.length === 0 || !userResult.rows[0].is_active) {
            return res.status(401).json({ error: 'Usuario no válido o inactivo' });
        }

        req.user = userResult.rows[0];
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'Token expirado' });
        }
        return res.status(401).json({ error: 'Token inválido' });
    }
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).json({ error: 'No tienes permisos para esta acción' });
        }
        next();
    };
};

// ============================================
// RUTAS DE AUTENTICACIÓN
// ============================================

// POST /api/auth/register
app.post('/api/auth/register',
    authLimiter,
    [
        body('fullName').trim().isLength({ min: 2, max: 150 }).withMessage('Nombre inválido'),
        body('email').isEmail().normalizeEmail().withMessage('Email inválido'),
        body('password').isLength({ min: 6 }).withMessage('La contraseña debe tener al menos 6 caracteres'),
        body('role').optional().isIn(['estudiante', 'profesor']).withMessage('Rol inválido')
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { fullName, email, password, role = 'estudiante' } = req.body;

        try {
            // Verificar email único
            const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
            if (existing.rows.length > 0) {
                return res.status(409).json({ error: 'El email ya está registrado' });
            }

            const hashedPassword = await bcrypt.hash(password, 12);

            const result = await pool.query(
                `INSERT INTO users (full_name, email, password_hash, role, email_verified)
                 VALUES ($1, $2, $3, $4, false)
                 RETURNING id, full_name, email, role, created_at`,
                [fullName, email, hashedPassword, role]
            );

            const user = result.rows[0];
            const token = generateToken({ userId: user.id, email: user.email, role: user.role });

            res.status(201).json({
                message: 'Usuario registrado exitosamente',
                user: {
                    id: user.id,
                    fullName: user.full_name,
                    email: user.email,
                    role: user.role
                },
                token
            });
        } catch (error) {
            console.error('Error en registro:', error);
            res.status(500).json({ error: 'Error al registrar usuario' });
        }
    }
);

// POST /api/auth/login
app.post('/api/auth/login',
    authLimiter,
    [
        body('email').isEmail().normalizeEmail(),
        body('password').notEmpty()
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { email, password } = req.body;

        try {
            const result = await pool.query(
                'SELECT id, full_name, email, password_hash, role, is_active, email_verified FROM users WHERE email = $1',
                [email]
            );

            if (result.rows.length === 0) {
                return res.status(401).json({ error: 'Credenciales inválidas' });
            }

            const user = result.rows[0];

            if (!user.is_active) {
                return res.status(401).json({ error: 'Cuenta desactivada' });
            }

            const validPassword = await bcrypt.compare(password, user.password_hash);
            if (!validPassword) {
                return res.status(401).json({ error: 'Credenciales inválidas' });
            }

            // Actualizar last_login
            await pool.query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

            const token = generateToken({
                userId: user.id,
                email: user.email,
                role: user.role
            });

            res.json({
                message: 'Login exitoso',
                user: {
                    id: user.id,
                    fullName: user.full_name,
                    email: user.email,
                    role: user.role,
                    emailVerified: user.email_verified
                },
                token
            });
        } catch (error) {
            console.error('Error en login:', error);
            res.status(500).json({ error: 'Error al iniciar sesión' });
        }
    }
);

// GET /api/auth/me
app.get('/api/auth/me', authenticate, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT u.id, u.full_name, u.email, u.role, u.avatar_url, u.created_at,
                    COUNT(DISTINCT vp.video_id) as videos_in_progress,
                    COUNT(DISTINCT CASE WHEN vp.is_completed THEN vp.video_id END) as videos_completed
             FROM users u
             LEFT JOIN video_progress vp ON vp.user_id = u.id
             WHERE u.id = $1
             GROUP BY u.id`,
            [req.user.id]
        );

        res.json({ user: result.rows[0] });
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener perfil' });
    }
});

// ============================================
// RUTAS DE VIDEOS
// ============================================

// GET /api/videos - Listar videos (público para estudiantes)
app.get('/api/videos', async (req, res) => {
    try {
        const { category, search, limit = 20, offset = 0 } = req.query;

        let query = `
            SELECT v.id, v.title, v.description, v.video_url, v.thumbnail_url,
                   v.duration, v.view_count, v.tags, v.published_at,
                   c.id as category_id, c.name as category_name, c.slug as category_slug, c.color as category_color,
                   u.full_name as uploaded_by_name
            FROM videos v
            LEFT JOIN categories c ON v.category_id = c.id
            LEFT JOIN users u ON v.uploaded_by = u.id
            WHERE v.is_published = true
        `;
        const params = [];
        let paramCount = 0;

        if (category) {
            paramCount++;
            query += ` AND c.slug = $${paramCount}`;
            params.push(category);
        }

        if (search) {
            paramCount++;
            query += ` AND (v.title ILIKE $${paramCount} OR v.description ILIKE $${paramCount} OR $${paramCount} = ANY(v.tags))`;
            params.push(`%${search}%`);
        }

        query += ` ORDER BY v.published_at DESC LIMIT $${++paramCount} OFFSET $${++paramCount}`;
        params.push(parseInt(limit), parseInt(offset));

        const result = await pool.query(query, params);

        // Si hay usuario autenticado, agregar progreso
        const authHeader = req.headers.authorization;
        if (authHeader && authHeader.startsWith('Bearer ')) {
            try {
                const token = authHeader.split(' ')[1];
                const decoded = verifyToken(token);

                const progressResult = await pool.query(
                    'SELECT video_id, progress_percent, is_completed FROM video_progress WHERE user_id = $1',
                    [decoded.userId]
                );

                const progressMap = {};
                progressResult.rows.forEach(p => {
                    progressMap[p.video_id] = p;
                });

                result.rows.forEach(video => {
                    if (progressMap[video.id]) {
                        video.progress = progressMap[video.id].progress_percent;
                        video.is_completed = progressMap[video.id].is_completed;
                    } else {
                        video.progress = 0;
                        video.is_completed = false;
                    }
                });
            } catch (e) {
                // Token inválido, ignorar progreso
            }
        }

        res.json({ videos: result.rows, count: result.rows.length });
    } catch (error) {
        console.error('Error al listar videos:', error);
        res.status(500).json({ error: 'Error al obtener videos' });
    }
});

// GET /api/videos/:id - Detalle de video
app.get('/api/videos/:id', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT v.*, c.name as category_name, c.slug as category_slug, c.color as category_color,
                    u.full_name as uploaded_by_name
             FROM videos v
             LEFT JOIN categories c ON v.category_id = c.id
             LEFT JOIN users u ON v.uploaded_by = u.id
             WHERE v.id = $1 AND v.is_published = true`,
            [req.params.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Video no encontrado' });
        }

        // Incrementar contador de vistas
        await pool.query('UPDATE videos SET view_count = view_count + 1 WHERE id = $1', [req.params.id]);

        res.json({ video: result.rows[0] });
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener video' });
    }
});

// POST /api/videos - Crear video (solo admin/profesor)
app.post('/api/videos',
    authenticate,
    authorize('administrador', 'profesor'),
    [
        body('title').trim().isLength({ min: 1, max: 255 }),
        body('videoUrl').isURL(),
        body('duration').isInt({ min: 1 }),
        body('categoryId').optional().isUUID()
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { title, description, videoUrl, thumbnailUrl, duration, categoryId, tags } = req.body;

        try {
            const result = await pool.query(
                `INSERT INTO videos (title, description, video_url, thumbnail_url, duration, category_id, uploaded_by, tags, is_published, published_at)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, NOW())
                 RETURNING *`,
                [title, description, videoUrl, thumbnailUrl, duration, categoryId, req.user.id, tags]
            );

            res.status(201).json({ video: result.rows[0] });
        } catch (error) {
            console.error('Error al crear video:', error);
            res.status(500).json({ error: 'Error al crear video' });
        }
    }
);

// ============================================
// RUTAS DE PROGRESO
// ============================================

// GET /api/progress - Progreso del usuario
app.get('/api/progress', authenticate, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT vp.*, v.title, v.thumbnail_url, v.duration, c.name as category_name
             FROM video_progress vp
             JOIN videos v ON vp.video_id = v.id
             LEFT JOIN categories c ON v.category_id = c.id
             WHERE vp.user_id = $1
             ORDER BY vp.last_watched_at DESC`,
            [req.user.id]
        );

        res.json({ progress: result.rows });
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener progreso' });
    }
});

// POST /api/progress - Actualizar progreso
app.post('/api/progress', authenticate, async (req, res) => {
    const { videoId, progressSeconds, progressPercent } = req.body;

    if (!videoId || progressPercent === undefined) {
        return res.status(400).json({ error: 'Datos incompletos' });
    }

    try {
        const isCompleted = progressPercent >= 95;

        const result = await pool.query(
            `INSERT INTO video_progress (user_id, video_id, progress_seconds, progress_percent, is_completed, completed_at, last_watched_at)
             VALUES ($1, $2, $3, $4, $5, CASE WHEN $5 THEN NOW() ELSE NULL END, NOW())
             ON CONFLICT (user_id, video_id)
             DO UPDATE SET
                 progress_seconds = EXCLUDED.progress_seconds,
                 progress_percent = EXCLUDED.progress_percent,
                 is_completed = EXCLUDED.is_completed,
                 completed_at = CASE WHEN EXCLUDED.is_completed AND NOT video_progress.is_completed THEN NOW() ELSE video_progress.completed_at END,
                 last_watched_at = NOW()
             RETURNING *`,
            [req.user.id, videoId, progressSeconds || 0, progressPercent, isCompleted]
        );

        res.json({ progress: result.rows[0] });
    } catch (error) {
        console.error('Error al actualizar progreso:', error);
        res.status(500).json({ error: 'Error al actualizar progreso' });
    }
});

// ============================================
// RUTAS DE VIDEOS GUARDADOS
// ============================================

// GET /api/saved - Videos guardados
app.get('/api/saved', authenticate, async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT sv.*, v.title, v.thumbnail_url, v.duration, c.name as category_name
             FROM saved_videos sv
             JOIN videos v ON sv.video_id = v.id
             LEFT JOIN categories c ON v.category_id = c.id
             WHERE sv.user_id = $1
             ORDER BY sv.created_at DESC`,
            [req.user.id]
        );

        res.json({ saved: result.rows });
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener videos guardados' });
    }
});

// POST /api/saved - Guardar video
app.post('/api/saved', authenticate, async (req, res) => {
    const { videoId } = req.body;
    if (!videoId) return res.status(400).json({ error: 'Video ID requerido' });

    try {
        await pool.query(
            'INSERT INTO saved_videos (user_id, video_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [req.user.id, videoId]
        );
        res.json({ message: 'Video guardado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al guardar video' });
    }
});

// DELETE /api/saved/:videoId - Eliminar de guardados
app.delete('/api/saved/:videoId', authenticate, async (req, res) => {
    try {
        await pool.query(
            'DELETE FROM saved_videos WHERE user_id = $1 AND video_id = $2',
            [req.user.id, req.params.videoId]
        );
        res.json({ message: 'Video eliminado de guardados' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar video' });
    }
});

// ============================================
// RUTAS DE CATEGORÍAS
// ============================================

// GET /api/categories - Listar categorías
app.get('/api/categories', async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT c.*, COUNT(v.id) as video_count
             FROM categories c
             LEFT JOIN videos v ON v.category_id = c.id AND v.is_published = true
             WHERE c.is_active = true
             GROUP BY c.id
             ORDER BY c.sort_order`
        );
        res.json({ categories: result.rows });
    } catch (error) {
        res.status(500).json({ error: 'Error al obtener categorías' });
    }
});

// ============================================
// RUTAS DE ESTADÍSTICAS (Dashboard)
// ============================================

// GET /api/stats - Estadísticas del estudiante
app.get('/api/stats', authenticate, async (req, res) => {
    try {
        // Total videos disponibles
        const totalVideos = await pool.query('SELECT COUNT(*) FROM videos WHERE is_published = true');

        // Videos en progreso
        const inProgress = await pool.query(
            'SELECT COUNT(*) FROM video_progress WHERE user_id = $1 AND is_completed = false AND progress_percent > 0',
            [req.user.id]
        );

        // Videos completados
        const completed = await pool.query(
            'SELECT COUNT(*) FROM video_progress WHERE user_id = $1 AND is_completed = true',
            [req.user.id]
        );

        // Horas vistas totales (estimado)
        const hoursResult = await pool.query(
            'SELECT COALESCE(SUM(progress_seconds), 0) as total_seconds FROM video_progress WHERE user_id = $1',
            [req.user.id]
        );
        const totalHours = (hoursResult.rows[0].total_seconds / 3600).toFixed(1);

        // Videos recientes
        const recent = await pool.query(
            `SELECT v.id, v.title, v.thumbnail_url, v.duration, c.name as category_name
             FROM videos v
             LEFT JOIN categories c ON v.category_id = c.id
             WHERE v.is_published = true
             ORDER BY v.published_at DESC LIMIT 5`
        );

        res.json({
            totalVideos: parseInt(totalVideos.rows[0].count),
            inProgress: parseInt(inProgress.rows[0].count),
            completed: parseInt(completed.rows[0].count),
            totalHours: parseFloat(totalHours),
            recentVideos: recent.rows
        });
    } catch (error) {
        console.error('Error en stats:', error);
        res.status(500).json({ error: 'Error al obtener estadísticas' });
    }
});

// ============================================
// RUTAS DE ADMIN
// ============================================

// GET /api/admin/users - Listar usuarios (solo admin)
app.get('/api/admin/users', authenticate, authorize('administrador'), async (req, res) => {
    try {
        const result = await pool.query(
            `SELECT id, full_name, email, role, is_active, email_verified, last_login, created_at
             FROM users ORDER BY created_at DESC`
        );
        res.json({ users: result.rows });
    } catch (error) {
        res.status(500).json({ error: 'Error al listar usuarios' });
    }
});

// PATCH /api/admin/users/:id - Actualizar usuario (solo admin)
app.patch('/api/admin/users/:id', authenticate, authorize('administrador'), async (req, res) => {
    const { role, isActive } = req.body;
    try {
        const result = await pool.query(
            'UPDATE users SET role = COALESCE($1, role), is_active = COALESCE($2, is_active) WHERE id = $3 RETURNING id, full_name, email, role, is_active',
            [role, isActive, req.params.id]
        );
        res.json({ user: result.rows[0] });
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar usuario' });
    }
});

// ============================================
// HEALTH CHECK
// ============================================
app.get('/api/health', async (req, res) => {
    try {
        await pool.query('SELECT 1');
        res.json({ status: 'ok', database: 'connected', timestamp: new Date().toISOString() });
    } catch (error) {
        res.status(503).json({ status: 'error', database: 'disconnected' });
    }
});

// ============================================
// INICIAR SERVIDOR
// ============================================
app.listen(PORT, () => {
    console.log('');
    console.log('🎓 EduStream API');
    console.log('================');
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📚 Documentación de endpoints:`);
    console.log(`   POST /api/auth/register     - Registro`);
    console.log(`   POST /api/auth/login        - Login`);
    console.log(`   GET  /api/auth/me           - Perfil`);
    console.log(`   GET  /api/videos            - Listar videos`);
    console.log(`   GET  /api/videos/:id        - Detalle video`);
    console.log(`   GET  /api/progress          - Progreso usuario`);
    console.log(`   POST /api/progress          - Actualizar progreso`);
    console.log(`   GET  /api/saved             - Videos guardados`);
    console.log(`   GET  /api/categories        - Categorías`);
    console.log(`   GET  /api/stats             - Estadísticas`);
    console.log(`   GET  /api/health            - Health check`);
    console.log('');
});

module.exports = app;